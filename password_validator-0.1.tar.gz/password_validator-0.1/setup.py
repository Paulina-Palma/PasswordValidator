from setuptools import setup

setup(
    name='password_validator',
    version='0.1',
    description='Collection of password validators',
    author='Paula Palma',
    email='paulina.anna.palma@gmail.com',
    packages=['password_validator'],
    install_requires=['requests']
)